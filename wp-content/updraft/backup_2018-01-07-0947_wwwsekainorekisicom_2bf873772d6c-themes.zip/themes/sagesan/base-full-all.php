<?php
use Roots\Sage\Setup;
use Roots\Sage\Wrapper;
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<?php get_template_part('templates/head'); ?>
<body <?php body_class('base-full-all'); ?>>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MX2JBZ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
  <!--[if IE]>
  <div class="alert alert-warning">
        <?php _e('You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.', 'sage'); ?>
      </div>
      <![endif]-->

      <?php
      do_action('get_header');
      get_template_part( 'parts/sidenav' )
    //get_template_part('parts/sidenav');
      ?>
      <main id="Main" class="wrap">
        <div class="wrap container" role="document">
          <?php if ( function_exists('yoast_breadcrumb') )
          {yoast_breadcrumb('<div class="breadcrumbs text-small">','</div>');} ?>
          <div class="content row">
            <section id="main-col" class="main col s12 keycover">
              <?php get_template_part( 'templates/content-full-all' ); ?>
            </section><!-- /.main -->
          </div><!-- /.content -->
        </div><!-- /.wrap -->
      </main>
      <?php
      do_action('get_footer');
      get_template_part('templates/footer');
      get_template_part('parts/footer','custom-field');
      wp_footer();
      ?>

      <?php get_template_part('parts/footer', 'outside'); ?>
    </body>
    </html>
