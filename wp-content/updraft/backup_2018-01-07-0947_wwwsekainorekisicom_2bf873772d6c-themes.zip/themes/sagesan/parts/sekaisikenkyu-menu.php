<div class="margin-bottom2">
<p class="small margin-bottom0">世界史</p>
	<?php
	wp_nav_menu( array(
		'menu' => 'sekaisi-1',
		'menu_class'      => 'flex-container subnav',
		'fallback_cb'     => 'wp_page_menu',
		'echo'            => true,
		'depth'           => 1
		));
		?>
<p class="small margin-bottom0">日本史</p>
	<?php
	wp_nav_menu( array(
		'menu' => 'nihonsi-1',
		'menu_class'      => 'flex-container subnav',
		'fallback_cb'     => 'wp_page_menu',
		'echo'            => true,
		'depth'           => 1
		));
		?>
	</div>