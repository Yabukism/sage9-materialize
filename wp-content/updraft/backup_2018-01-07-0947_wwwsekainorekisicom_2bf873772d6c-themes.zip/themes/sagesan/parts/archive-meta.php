<div class="history-meta clearfix col s12">

  <div class="row">
    <div class="col s6">
  <span class="meta-category">
    <?php if(has_term('','keywords_family')){
      echo '<i class="tiny material-icons">folder_open</i>';
      the_terms( $post->ID, 'keywords_family', '', '/' );
    } else {
      echo '<i class="tiny material-icons">folder_open</i> <span itemprop="genre">';
      the_category(' &gt; ');
      echo '</span>';
    }
    ?>
  </span>
    </div>
    <div class="col s6">
      <time class="entry-date updated" datetime="<?= get_post_time('c', true); ?>" itemprop="dateModified"><i class="tiny material-icons">update</i> <span class="margin-right05">最終更新日</span><?= the_modified_date(); ?>
      </time>
    </div>
  </div>
  <?php get_template_part('templates/entry','meta-flag'); ?>
</div>