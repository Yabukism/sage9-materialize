<!-- bluet-keywords-tooltip-generator line 206-->
'.$tooltipy_glossary_thumb.do_shortcode(get_the_content('MORE')).'</div>
<!-- bluet-keywords-tooltip-generator line 196-->
$tooltipy_glossary_thumb='<div class="kttg_glossary_element_thumbnail">'.get_the_post_thumbnail('','thumbnail','').'</div>';
<!-- bluet-keywords-tooltip-generator add-style line 113-->
<!-- bluet-keywords index.php line57 -->
<!-- bluet-keywords keyword-posttype.php line33 -->
<!-- related post by taxonomy functions-thumbnail.php line231,243, 239-->
