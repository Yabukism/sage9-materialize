<section class="widget widget_text">
  <h3 class="widget-title"><?php _e('COUNTRY','sage'); ?></h3>
  <ul class="collapsible" data-collapsible="accordion">

    <li>
      <div class="collapsible-header">西ヨーロッパ<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=126'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">南ヨーロッパ<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=95'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">東ヨーロッパ<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=110'); ?>
        </ul>
      </div>
    </li> 

    <li>
      <div class="collapsible-header">北ヨーロッパ<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=172'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">西アジア<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=125'); ?>
        </ul>
      </div>
    </li> 

    <li>
      <div class="collapsible-header">東アジア<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=109'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">南アジア<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=93'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">東南アジア<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=111'); ?>
        </ul>
      </div>
    </li> 

    <li>
      <div class="collapsible-header">オセアニア<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=53'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">北アメリカ<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=92'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">中央アメリカ<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=90'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">南アメリカ<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=94'); ?>
        </ul>
      </div>
    </li>
    <li>
      <div class="collapsible-header">アフリカ<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=38'); ?>
        </ul>
      </div>
    </li>
    <li>
      <div class="collapsible-header">独立国家共同体<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=166'); ?>
        </ul>
      </div>
    </li>
    <li>
      <div class="collapsible-header">世界<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=country&title_li=&child_of=91'); ?>
        </ul>
      </div>
    </li>
  </ul>
</section>