<?php
if ( function_exists( 'sharing_display' ) ) {
	sharing_display( '', true );
}
?>