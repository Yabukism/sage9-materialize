<div id="top-adsense" class="padding-1-0-2">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-format="fluid"
     data-ad-layout="in-article"
     data-ad-client="ca-pub-2050911374369150"
     data-ad-slot="2089860698"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>