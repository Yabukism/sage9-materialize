<section class="widget widget-movie-info z-depth-1">
  <h3 class="widget-title movie-title"><?php _e('MOVIE INFORMATION' , 'sage'); ?></h3>
  <?php if(post_custom('wpcf-amazon')): ?>
    <div class="amazon-image"><?php echo apply_filters('the_content', get_post_meta($post->ID, 'wpcf-amazon', true)); ?></div>
  <?php endif; ?>
  <dl itemscope itemtype="http://data-vocabulary.org/Review">
    <?php if(post_custom('wpcf-movie-title')): ?>
      <dt><?php _e('Movie title' , 'sage'); ?></dt>
      <dd itemprop="reviewer"><?php echo post_custom('wpcf-movie-title'); ?></dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-directed')): ?>
      <dt>
        <?php _e('Directed' , 'sage'); ?>
      </dt>
      <dd>
        <?php echo post_custom('wpcf-directed'); ?>
      </dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-starring')): ?>
      <dt><?php _e('Starring' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-starring'); ?></dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-release')): ?>
      <dt><?php _e('Release Date' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-release'); ?></dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-p_country')): ?>
      <dt><?php _e('Fabricated country' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-p_country'); ?></dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-s_country')): ?>
      <dt><?php _e('Stage Countries' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-s_country'); ?></dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-models')): ?>
      <dt><?php _e('Model' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-models'); ?></dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-winning')): ?>
      <dt><?php _e('Winning' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-winning'); ?></dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-reviws-date')): ?>
      <dt><?php _e('Reviwed Date' , 'sage'); ?></dt>
      <dd><time itemprop="dtreviewed" datetime="<?php echo post_custom("wpcf-reviws-date"); ?>"><?php echo post_custom("wpcf-reviws-date"); ?></time></dd>
    <?php endif; ?>      
    <?php if(post_custom('wpcf-review')): ?>
      <dt><?php _e('My Reviw' , 'sage'); ?></dt>
      <dd itemprop="itemreviewed"><?php echo post_custom('wpcf-review'); ?></dd>
    <?php endif; ?>
    <?php if(post_custom('wpcf-rating')): ?>  
      <dt><?php _e('Rating' , 'sage'); ?></dt>
      <dd><span class="hide" itemprop="rating"><?php echo post_custom('wpcf-rating'); ?></span>
        <div class="rating-star" id="score-callback" data-score="<?php echo post_custom('wpcf-rating'); ?>"></div>
      </dd>
    <?php endif; ?>       
    <?php if(post_custom('wpcf-note')): ?>  
      <dt><?php _e('Remarks' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-note'); ?></dd>
    <?php endif; ?>  
  </dl>
</section>