<aside class="single-bottom-nav clearfix">
  <div class="row">
    <?php $prevpost = get_adjacent_post();?>
    <?php if($prevpost):?>
      <?php if( has_post_thumbnail($prevpost->ID)): ?>
        <?php
        $image_id = get_post_thumbnail_id($prevpost->ID);
        $image_url = wp_get_attachment_image_src($image_id, 'thumbnail');
        ?>
        <div class="col s6 m6 l6 prevpost">
        <div class="wrapper hoverable">
            <a href="<?php echo get_permalink($prevpost->ID);?>">
              <div class="hide-on-med-and-down col m4 l4 padding-0" style="background-image: url(<?php echo $image_url[0]; ?>)">
              </div>
              <div class="col s12 m12 l8 nav-text">
                <span class="label">PREVIOUS</span>
                <span class="nav-title"><?php echo $prevpost->post_title;?></span>
              </div>
              </a>
            </div>        
        </div>
      <?php endif; ?>
    <?php endif; ?>
    <?php $nextpost = get_adjacent_post(false,'', false);?>
    <?php if($nextpost):?>
      <?php if( has_post_thumbnail($nextpost->ID)): ?>
        <?php
        $image_id = get_post_thumbnail_id($nextpost->ID);
        $image_url = wp_get_attachment_image_src($image_id, 'thumbnail');
        ?>
        <div class="col s6 m6 l6 nextpost">
          <div class="wrapper hoverable">
            <a href="<?php echo get_permalink($nextpost->ID);?>">
              <div class="col s12 m12 l8 nav-text right-align">
                <span class="label">NEXT</span>
                <span class="nav-title"><?php echo $nextpost->post_title;?></span>
              </div>
              <div class="col m4 l4 padding-0 hide-on-med-and-down" style="background-image: url(<?php echo $image_url[0]; ?>)">
              </div>
            </a>
          </div>
        </div>
    <?php endif; ?>
  <?php endif; ?>
  </div>
</aside>
