<section id="This-info-widget" class="widget widget_custom this-info z-depth-1">
	<h3 class="widget-title">
		<?php _e('POST INFORMATION','sage'); ?>
	</h3>
	<ul>
		<!--   地図-->
		<?php if(post_custom('wpcf-s-map')): ?>
		<li>
			<div class="sidebar-map margin-bottom2">
				<?php
        $var = get_post_meta($post->ID, 'wpcf-s-map', true);
        $var2 = get_post_meta($post->ID, 'wpcf-s-map-w', true);
        if($var == '')
        {
        }else {
          echo do_shortcode( '[display_map height="200" zoom="5" scroll_wheel="false" address1=" '. $var .' | '. $var2 .' "]' );
        }
        ?>
			</div>
			<!-- /.sidebar-map -->
		</li>
		<?php endif; ?>
		<!--    年代-->
		<li>
			<div class="type"><i class="tiny material-icons">date_range</i>
				<?php _e('Age','sage'); ?>
			</div>
			<div class="value age-value">
				<?php
        $product_terms = wp_get_object_terms( $post->ID, 'age' );
        if ( ! empty( $product_terms ) ) {
          if ( ! is_wp_error( $product_terms ) ) {
            foreach( $product_terms as $term ) {
              echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'age' ) .'">' . esc_html( $term->name ) . '</a>';
            }
          }
        }
        ?>
			</div>
		</li>
		<!--    開始紀元年月日-->
		<?php if(post_custom('wpcf-start-year')): ?>
		<div class="row margin-bottom0">
			<div class="col s6">
				<div class="type"><i class="tiny material-icons">history</i>
					<?php _e('Start','sage'); ?>
				</div>
				<div class="value no-btn">
					<?php echo post_custom('wpcf-start-era'); ?>
					<?php echo post_custom('wpcf-start-year'); ?>

					<?php if(post_custom('wpcf-start-month')): ?>
					<?php _e('-','sage'); ?>
					<?php echo post_custom('wpcf-start-month'); ?>
					<?php endif; ?>

					<?php if(post_custom('wpcf-start-day')): ?>
					<?php _e('-','sage'); ?>
					<?php echo post_custom('wpcf-start-day'); ?>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			</div>
			<div class="col s6">
				<!--    終了紀元・年月日-->
				<?php if(post_custom('wpcf-end-year')): ?>
				<div class="type"><i class="tiny material-icons">history</i>
					<?php _e('End','sage'); ?>
				</div>
				<div class="value no-btn">
					<?php echo post_custom('wpcf-end-era'); ?>
					<?php echo post_custom('wpcf-end-year'); ?>

					<?php if(post_custom('wpcf-end-month')): ?>
					<?php _e('-','sage'); ?>
					<?php echo post_custom('wpcf-end-month'); ?>
					<?php endif; ?>

					<?php if(post_custom('wpcf-end-day')): ?>
					<?php _e('-','sage'); ?>
					<?php echo post_custom('wpcf-end-day'); ?>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			</div>
		</div>


		<!--    時代-->
		<?php
    $product_terms = wp_get_object_terms( $post->ID,  'era-name' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">label_outline</i>';
        echo ( __('Era', 'sage'));
        echo '</div>';
        echo '<div class="value ela-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'era-name' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
			<!--    君主-->
			<?php
    $product_terms = wp_get_object_terms( $post->ID,  'historypresidents' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">assignment_ind</i>';
        echo ( __('Emperor', 'sage'));
        echo '</div>';
        echo '<div class="value person-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'historypresidents' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
				<!--    政策-->
				<?php
    $product_terms = wp_get_object_terms( $post->ID,  'policy' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">assignment</i>';
        echo ( __('policy', 'sage'));
        echo '</div>';
        echo '<div class="value art-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'policy' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
					<!--    輸出入品-->
					<?php
    $product_terms = wp_get_object_terms( $post->ID,  'export-items' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">local_shipping</i>';
        echo ( __('輸出入品', 'sage'));
        echo '</div>';
        echo '<div class="value art-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'export-items' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
						<!--    皇族    -->
						<?php
    $product_terms = wp_get_object_terms( $post->ID,  'royalty' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">person</i>';
        echo ( __('royalty', 'sage'));
        echo '</div>';
        echo '<div class="value person-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'royalty' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
							<!--    将軍-->
							<?php
    $product_terms = wp_get_object_terms( $post->ID,  'j_general' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">person</i>';
        echo ( __('j_general', 'sage'));
        echo '</div>';
        echo '<div class="value person-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'j_general' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
								<!--    戦争-->
								<?php
    $product_terms = wp_get_object_terms( $post->ID,  'history_war' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">close</i>';
        echo ( __('War', 'sage'));
        echo '</div>';
        echo '<div class="value war-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'history_war' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
									<!--    芸術    -->
									<?php
    $product_terms = wp_get_object_terms( $post->ID,  'historyart' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">brush</i>';
        echo ( __('art', 'sage'));
        echo '</div>';
        echo '<div class="value art-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'historyart' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
										<!--    文化人-->
										<?php
    $product_terms = wp_get_object_terms( $post->ID,  'culture-artist' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">perm_identity</i>';
        echo ( __('文化人', 'sage'));
        echo '</div>';
        echo '<div class="value art-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'culture-artist' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
											<!--    建築  -->
											<?php
    $product_terms = wp_get_object_terms( $post->ID,  'historybuilding' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">business</i>';
        echo ( __('Building', 'sage'));
        echo '</div>';
        echo '<div class="value building-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'historybuilding' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
												<!--    民族-->
												<?php
    $product_terms = wp_get_object_terms( $post->ID,  'historypeople' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">people</i>';
        echo ( __('Ethnic', 'sage'));
        echo '</div>';
        echo '<div class="value ethnic-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'historypeople' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
													<!--    場所-->
													<?php if(post_custom('wpcf-map_country')): ?>
													<li>
														<div class="type"><i class="tiny material-icons">place</i>場所</div>
														<div class="value no-btn">
															<?php echo post_custom('wpcf-map_country'); ?>
															<?php echo post_custom('wpcf-state'); ?>
															<?php echo post_custom('wpcf-city'); ?>
														</div>
													</li>
													<?php endif; ?>

	</ul>
</section>
