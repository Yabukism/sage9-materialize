<section class="widget widget_categories">
<h3 class="widget-title"><?php _e('CHAPTER','sage'); ?></h3>
<?php 
$taxonomy     = 'chapter';
$orderby      = 'id'; 
$show_count   = 1;      // 表示するなら 1、しないなら 0
$pad_counts   = 1;      // 子孫のカウントも合計するなら 1、しないなら 0
$hierarchical = 1;      // 階層表示するなら 1、しないなら 0
$title        = '';
$depth								= 2;
$exclude						= 9062;    // 世界史除外8526;

$args = array(
  'taxonomy'     => $taxonomy,
  'orderby'      => $orderby,
		'exclude'						=> $exclude,
  'show_count'   => $show_count,
  'pad_counts'   => $pad_counts,
  'hierarchical' => $hierarchical,
  'title_li'     => $title,
		'depth'				 			=> $depth
);
?>

<ul>
<?php wp_list_categories( $args ); ?>
</ul>
</section>