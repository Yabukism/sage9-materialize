<section class="widget widget_categories">
<h3 class="widget-title"><?php _e('KEYWORD CATEGORY','sage'); ?></h3>
<?php 
$taxonomy     = 'keywords_family';
$orderby      = 'name'; 
$show_count   = 1;      // 表示するなら 1、しないなら 0
$pad_counts   = 1;      // 子孫のカウントも合計するなら 1、しないなら 0
$hierarchical = 0;      // 階層表示するなら 1、しないなら 0
$title        = '';

$args = array(
  'taxonomy'     => $taxonomy,
  'orderby'      => $orderby,
  'show_count'   => $show_count,
  'pad_counts'   => $pad_counts,
  'hierarchical' => $hierarchical,
  'title_li'     => $title
);
?>

<ul>
<?php wp_list_categories( $args ); ?>
</ul>
</section>