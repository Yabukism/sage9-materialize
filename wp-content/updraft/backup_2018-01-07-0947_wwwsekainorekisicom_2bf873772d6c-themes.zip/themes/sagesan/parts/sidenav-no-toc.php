<header id="Main-header" class="navbar-fixed">
  <!-- Dropdown Structure -->
  <?php
  wp_nav_menu (
    array(
      'theme_location'  => 'top_navigation1',
      'container'       => false,
      'menu_id'         => 'dropdown1',
      'menu_class'      => 'right',
      'items_wrap'      => '<ul id="%1$s" class="dropdown-content %2$s">%3$s</ul>'
      )
    );
    ?>
    <?php
    wp_nav_menu (
      array(
        'theme_location'  => 'top_navigation2',
        'container'       => false,
        'menu_id'         => 'dropdown2',
        'menu_class'      => 'right',
        'items_wrap'      => '<ul id="%1$s" class="dropdown-content %2$s">%3$s</ul>'
        )
      );
      ?>
      <?php
      wp_nav_menu (
        array(
          'theme_location'  => 'top_navigation4',
          'container'       => false,
          'menu_id'         => 'dropdown4',
          'menu_class'      => 'right',
          'items_wrap'      => '<ul id="%1$s" class="dropdown-content %2$s">%3$s</ul>'
          )
        );
        ?>

        <nav class="top-nav">
          <div class="container">
            <div class="nav-wrapper">
              <a href="#" data-activates="nav-mobile" class="button-collapse top-nav full hide-on-large-only">
                <i class="material-icons">menu</i>
              </a>
              <ul class="right">
                <li>
                  <a class='dropdown-button' href='#' data-activates='dropdown1'>
                    <span class="display-l">カテゴリ&nbsp;&nbsp;<i class="material-icons right">arrow_drop_down</i></span>
                    <span class="display-m"><i class="material-icons">folder</i></span>
                  </a>
                </li>
                <li>
                  <a class='dropdown-button' href='#' data-activates='dropdown2'>
                    <span class="display-l">用語カテゴリ<i class="material-icons right">arrow_drop_down</i></span>
                    <span class="display-m"><i class="material-icons">folder_shared</i></span>
                  </a>
                </li>
                <li>
                  <a class='dropdown-button' href='#' data-activates='dropdown4'>
                    <span class="display-l">世界史年表&nbsp;<i class="material-icons right">arrow_drop_down</i></span>
                    <span class="display-m"><i class="material-icons">timeline</i></span>
                  </a>
                </li>
                <li class="hide-on-med-and-down">

                  <?php
                  wp_nav_menu (
                    array(
                      'theme_location'  => 'top_navigation3',
                      'container'       => false,
                      'menu_id'         => 'download-link',
                      'menu_class'      => 'right',
                      'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>'
                      )
                    );
                    ?>

                  </li>
                </ul>
              </div>
            </div>
          </nav>

          <ul id="nav-mobile" class="side-nav fixed">
            <?php if(is_single()) {
            }
            ?>
            <li class="brand-logo">
              <div class="valign-wrapper">
                <a class="valign waves-effect waves-light" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                  <img src="<?= get_template_directory_uri(); ?>/dist/images/logo.svg" alt="ホーム" width="255" height="40">
                </a>
              </div>
            </li>
            <li>
              <a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/timeline/' ) ); ?>"><i class="material-icons">account_balance</i>年表から探す</a>
            </li>
            <li>
              <a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/map-search/' ) ); ?>/"><i class="material-icons">add_location</i>地図から探す</a>
            </li>
            <li>
              <a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/keywords-lists/' ) ); ?>"><i class="material-icons">book</i>用語集</a>
            </li>
            <li>
              <a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/chronology/' ) ); ?>"><i class="material-icons">timeline</i>世界史年表</a>
            </li>
            <li>
              <a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/downloads/' ) ); ?>"><i class="material-icons">cloud_download</i>ダウンロード</a>
            </li>
            <li class="search">
              <?php get_search_form(); ?>
            </li>
          </ul>
        </header>


