<header id="Main-header" class="navbar-fixed">
	<!-- Dropdown Structure -->
	<?php
  wp_nav_menu (
    array(
      'theme_location'  => 'top_navigation1',
      'container'       => false,
      'menu_id'         => 'dropdown1',
      'menu_class'      => 'right',
      'items_wrap'      => '<ul id="%1$s" class="dropdown-content %2$s">%3$s</ul>'
      )
    );
    ?>
		<?php
    wp_nav_menu (
      array(
        'theme_location'  => 'top_navigation2',
        'container'       => false,
        'menu_id'         => 'dropdown2',
        'menu_class'      => 'right',
        'items_wrap'      => '<ul id="%1$s" class="dropdown-content %2$s">%3$s</ul>'
        )
      );
      ?>

				<?php
      wp_nav_menu (
        array(
          'theme_location'  => 'top_navigation3',
          'container'       => false,
          'menu_id'         => 'dropdown3',
          'menu_class'      => 'right',
          'items_wrap'      => '<ul id="%1$s" class="dropdown-content %2$s">%3$s</ul>'
          )
        );
        ?>
					<?php
//      wp_nav_menu (
//        array(
//          'theme_location'  => 'top_navigation5',
//          'container'       => false,
//          'menu_id'         => 'dropdown5',
//          'menu_class'      => 'right',
//          'items_wrap'      => '<ul id="%1$s" class="dropdown-content %2$s">%3$s</ul>'
//          )
//        );
        ?>
						<?php
//      wp_nav_menu (
//        array(
//          'theme_location'  => 'top_navigation6',
//          'container'       => false,
//          'menu_id'         => 'dropdown6',
//          'menu_class'      => 'right',
//				 'items_wrap'      => '<ul id="%1$s" class="dropdown-content %2$s">%3$s</ul>'
//          )
//        );
        ?>

							<nav class="top-nav">
								<div class="container">
									<div class="nav-wrapper">
										<a href="#" data-activates="nav-mobile" class="button-collapse top-nav full hide-on-large-only">
											<i class="material-icons">menu</i>
										</a>
										<ul class="right">
											<li>
												<a class='dropdown-button' href='#' data-activates='dropdown1'>
													<span class="display-l">カテゴリ&nbsp;&nbsp;<i class="material-icons right">arrow_drop_down</i></span>
													<span class="display-m"><i class="material-icons">folder</i></span>
												</a>
											</li>
											<li>
												<a class='dropdown-button' href='#' data-activates='dropdown2'>
													<span class="display-l">用語カテゴリ<i class="material-icons right">arrow_drop_down</i></span>
													<span class="display-m"><i class="material-icons">folder_shared</i></span>
												</a>
											</li>
<!--
											<li>
												<a class='dropdown-button' href='#' data-activates='dropdown5'>
													<span class="display-l">日本史&nbsp;<i class="material-icons right">arrow_drop_down</i></span>
													<span class="display-m"><i class="material-icons">school</i></span>
												</a>
											</li>
											<li>
												<a class='dropdown-button' href='#' data-activates='dropdown6' data-hover="hover" data-alignment="left">
													<span class="display-l">世界史&nbsp;<i class="material-icons right">arrow_drop_down</i></span>
													<span class="display-m"><i class="material-icons">school</i></span>
												</a>
											</li>
-->
											<li class="hide-on-med-and-down">
												<a class='dropdown-button' href='#' data-activates='dropdown3'>
													<span class="display-l">ダウンロード&nbsp;</span>
													<span class="display-m"><i class="material-icons">timeline</i></span>
												</a>
											</li>
										</ul>
									</div>
								</div>
							</nav>

							<ul id="nav-mobile" class="side-nav fixed">
								<li class="brand-logo">
									<div class="valign-wrapper">
										<a class="valign waves-effect waves-light" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                  <img src="<?= get_template_directory_uri(); ?>/dist/images/logo.svg" alt="ホーム" width="140" height="19">
                </a>
									</div>
								</li>
								<li>
									<a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/%E6%97%A5%E6%9C%AC%E5%8F%B2%E3%83%BB%E4%B8%96%E7%95%8C%E5%8F%B2%EF%BC%88%E7%9B%AE%E6%AC%A1%EF%BC%89/' ) ); ?>"><i class="material-icons">school</i>日本史/世界史</a>
								</li>
								<li>
									<a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/timeline/' ) ); ?>"><i class="material-icons">account_balance</i>年表から探す</a>
								</li>
								<li>
									<a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/map-search' ) ); ?>/"><i class="material-icons">add_location</i>地図から探す</a>
								</li>
								<li>
									<a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/keywords-lists/' ) ); ?>"><i class="material-icons">book</i>用語集</a>
								</li>
								<li>
									<a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/chronology/' ) ); ?>"><i class="material-icons">timeline</i>世界史年表</a>
								</li>
								<li>
									<a class="waves-effect waves-light" href="<?php echo esc_url( home_url( '/category/dl/' ) ); ?>"><i class="material-icons">cloud_download</i>ダウンロード</a>
								</li>
								<li class="search">
									<?php get_search_form(); ?>
								</li>
								<li class="toc">
									<?php dynamic_sidebar( 'toc-widgets' ); ?>
								</li>

								<li><p class="small center-align margin-bottom0">Sponsored Link</p>
								<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- 左サイドバー -->
<ins class="adsbygoogle"
     style="display:inline-block;width:200px;height:200px"
     data-ad-client="ca-pub-2050911374369150"
     data-ad-slot="4172560521"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
								</li>
							</ul>
							<div>
</header>
