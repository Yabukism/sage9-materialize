<p class="center-align small margin-bottom0">Sponsored Link</p>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- download-side -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2050911374369150"
     data-ad-slot="7185404678"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>