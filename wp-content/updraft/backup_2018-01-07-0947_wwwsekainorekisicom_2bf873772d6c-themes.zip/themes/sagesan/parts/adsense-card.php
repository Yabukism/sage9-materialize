<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout="image-top"
     data-ad-layout-key="-7h+18-br+dq+e0"
     data-ad-client="ca-pub-2050911374369150"
     data-ad-slot="4895454600"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
