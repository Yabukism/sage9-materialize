<?php wp_link_pages(
  array(
    'before' => '<div class="pagination mypage">',
    'after' => '',
    'link_before' => '',
    'link_after' => '',
    'next_or_number' => 'next',
    'previouspagelink' => __( '<div class="pagenation-arrow1"><i class="material-icons tiny">chevron_left</i></div>' ),
    'nextpagelink' => __( '<div class="pagenation-arrow2"><i class="material-icons tiny">chevron_right</i></div>' ),
    )
  );
  ?>

  <?php wp_link_pages(
    array(
      'before' => '<div class="pagenation-number">',
      'after' => '</div></div>',
      'link_before' => '<span class="page-numbers">',
      'link_after' => '</span>',
      'next_or_number' => 'number',
      )
    );
    ?>