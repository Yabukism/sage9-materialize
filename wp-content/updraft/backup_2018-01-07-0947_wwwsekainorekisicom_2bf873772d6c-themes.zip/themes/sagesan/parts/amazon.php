<div id="bottom-adsense" class="row padding-1-0-2">

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block; text-align:center;"
     data-ad-layout="in-article"
     data-ad-format="fluid"
     data-ad-client="ca-pub-2050911374369150"
     data-ad-slot="1173320101"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>

</div>