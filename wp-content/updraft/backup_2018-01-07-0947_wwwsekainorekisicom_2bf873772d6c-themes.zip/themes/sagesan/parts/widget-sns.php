

<p><a class="btn-floating waves-effect waves-light" href="#Main"><i class="material-icons">arrow_upward</i></a></p>

<p class="padding-top1"><a class="margin-right1" href="https://www.facebook.com/sekainorekishi/"><i class="icomoon icon-facebook"></i></a>
    <a href="https://twitter.com/joe___yabuki"><i class="icomoon icon-twitter"></i></a></p>
