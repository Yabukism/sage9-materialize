<p class="right-align margin-bottom0 grey-text small"><i class="material-icons">person_outline</i>by <span class="vcard author"><span class="fn post-author"><?php the_author(); ?></span></span></p>
