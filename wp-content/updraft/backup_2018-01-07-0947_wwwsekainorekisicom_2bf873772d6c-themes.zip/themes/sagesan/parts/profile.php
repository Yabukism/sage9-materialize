<?php if(get_post_meta($post->ID,'wpcf-profile-on',true) == 'ON'): ?>
<section class="widget widget_profile z-depth-1">
  <h3 class="widget-title"><?php _e('PROFILE','sage'); ?></h3>
  <?php if(post_custom('wpcf-title')): ?>
    <h4 class="profile-title center-align"><?php echo post_custom('wpcf-title'); ?></h4>
  <?php endif; ?>

  <?php if(post_custom('wpcf-portrait')): ?>
    <p class="portrait-img">
    <img src="<?php echo (post_custom('wpcf-portrait', array('output' => 'raw'))); ?>" /></p>
  <?php endif; ?>


  <dl>

  <?php if(post_custom('wpcf-dynasty')): ?>

      <dt><?php _e('王朝' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-dynasty'); ?>
    <?php endif; ?>    	
      <?php if(post_custom('wpcf-generations')): ?>
      <span class="padding-left1"><?php echo post_custom('wpcf-generations'); ?></span></dd>
    <?php endif; ?>   	


    <?php if(post_custom('wpcf-reign')): ?>
      <dt><?php _e('在位' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-reign'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-capital')): ?>
      <dt><?php _e('首都' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-capital'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-full_name')): ?>
      <dt><?php _e('姓名' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-full_name'); ?></dd>
    <?php endif; ?>

      <?php if(post_custom('wpcf-another-name')): ?>
      <dt><?php _e('別号' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-another-name'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-royal-family')): ?>
      <dt><?php _e('王家' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-royal-family'); ?></dd>
    <?php endif; ?>
    
    <?php if(post_custom('wpcf-born')): ?>
    <div class="row margin-bottom0">
    <div class="col s6">
    	<dt><?php _e('生誕' , 'sage'); ?></dt>
    	<dd><?php echo post_custom('wpcf-born'); ?></dd>
    	 <?php endif; ?>
    </div>
    <div class="col s6">
     <?php if(post_custom('wpcf-died')): ?>
      <dt><?php _e('死去' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-died'); ?></dd>
    <?php endif; ?>   	
    </div>
    </div>

    <?php if(post_custom('wpcf-burial')): ?>
      <dt><?php _e('埋葬' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-burial'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-spouse')): ?>
      <dt><?php _e('配偶者' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-spouse'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-child')): ?>
      <dt><?php _e('子女' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-child'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-father')): ?>
      <dt><?php _e('父親' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-father'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-mother')): ?>
      <dt><?php _e('母親' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-mother'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-known-for')): ?>
      <dt><?php _e('著名な実績' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-known-for'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-notable_work')): ?>
      <dt><?php _e('代表作' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-notable_work'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-movement')): ?>
      <dt><?php _e('運動・動向' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-movement'); ?></dd>
    <?php endif; ?>

    <?php if(post_custom('wpcf-other')): ?>
      <dt><?php _e('その他' , 'sage'); ?></dt>
      <dd><?php echo post_custom('wpcf-other'); ?></dd>
    <?php endif; ?>

  </dl>
</section>
<?php endif; ?>