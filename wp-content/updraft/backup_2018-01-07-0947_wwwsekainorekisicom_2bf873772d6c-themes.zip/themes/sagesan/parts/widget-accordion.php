<section class="widget widget_age">
  <h3 class="widget-title"><?php _e('AGE','sage'); ?></h3>
  <ul id="footer-age" class="collapsible" data-collapsible="accordion">

    <li>
      <div class="collapsible-header">3000年紀<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=age&title_li=&child_of=601'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">2000年紀<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=age&title_li=&child_of=600'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">1000年紀<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=age&title_li=&child_of=595'); ?>
        </ul>
      </div>
    </li> 

    <li>
      <div class="collapsible-header">紀元前1000年紀<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=age&title_li=&child_of=594'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">紀元前2000年紀<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=age&title_li=&child_of=608'); ?>
        </ul>
      </div>
    </li> 

    <li>
      <div class="collapsible-header">紀元前3000年紀<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=age&title_li=&child_of=607'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">紀元前4000年紀<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=age&title_li=&child_of=606'); ?>
        </ul>
      </div>
    </li>

    <li>
      <div class="collapsible-header">紀元前5000年紀以前<span class="icon"></span></div>
      <div class="collapsible-body">
        <ul>
          <?php wp_list_categories('taxonomy=age&title_li=&child_of=605'); ?>
        </ul>
      </div>
    </li> 
  </ul>
</section>