<?php if(has_term('','chapter')): ?>

<div class="col s12 chapter-nav margin-top2">
	<div class="col s6"><?php previous_post_link( '<p class="left-align small"><i class="material-icons">keyboard_arrow_left</i> %link</p>', '%title', TRUE, ' ', 'chapter' ); ?></div>
	<div class="col s6"><?php next_post_link('<p class="right-align small red-text">次のページ %link <i class="material-icons red-text">keyboard_arrow_right</i></p>', '%title' ,TRUE, ' ', 'chapter'); ?></div>
</div>
<p class="right-align small"><a href="/%E6%97%A5%E6%9C%AC%E5%8F%B2%E3%83%BB%E4%B8%96%E7%95%8C%E5%8F%B2%EF%BC%88%E7%9B%AE%E6%AC%A1%EF%BC%89/" target=_blank>日本史・世界史 一覧を見る <i class="material-icons">keyboard_arrow_right</i></a></p>

<?php endif; ?>


<?php if(post_is_in_descendant_category('8509')): ?>
<div class="col s12 chapter-nav margin-top2 margin-bottom1">
	<div class="col s6"><?php previous_post_link( '<p class="left-align small"><i class="material-icons">keyboard_arrow_left</i> %link</p>', '%title', TRUE); ?></div>
	<div class="col s6"><?php next_post_link('<p class="right-align small"> %link<i class="material-icons">keyboard_arrow_right</i></p>', '%title' ,TRUE); ?></div>
</div>
<?php endif; ?>