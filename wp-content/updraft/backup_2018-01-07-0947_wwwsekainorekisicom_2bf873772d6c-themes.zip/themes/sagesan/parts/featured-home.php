<section id="index-banner" role="banner">
  <div class="container">
    <div class="marketing row">
      <div class="tagline col s12 m5 l5">
        <h1><a href="<?php bloginfo( 'url' ); ?>" title="<?php bloginfo( 'name' ); ?>">
          <img src="<?php echo get_template_directory_uri(); ?>/dist/images/logo.svg" alt="<?php bloginfo( 'name' ); ?>"></a></h1>
          <p class="typo-body-2"><?php bloginfo( 'description' ); ?></p>
          <a role="button" class="waves-effect waves-light btn-large hide-on-small-only margin-bottom1" href="<?php bloginfo( 'url' );?>/category/dl/">Free Download</a>
          <div id="watch" class="s12 col hide-on-small-only">
            <a class="margin-right1" href="https://www.facebook.com/sekainorekishi/"><i class="icomoon icon-facebook"></i></a>
            <a href="https://twitter.com/joe___yabuki"><i class="icomoon icon-twitter"></i></a>
          </div>
        </div>

        <div class="fpmock col hide-on-small-only m7 l7">
        <img src="<?php echo get_template_directory_uri(); ?>/dist/images/home.svg" alt="世界の歴史まっぷ" width="696" height="402">
        </div>
      </div>
    </div>
  </section>
