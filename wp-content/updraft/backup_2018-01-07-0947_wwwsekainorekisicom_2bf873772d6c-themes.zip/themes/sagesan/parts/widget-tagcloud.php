<article class="widget widget_tag_cloud">
  <h3 class="widget-title"><?php _e('TAGS','sage'); ?></h3>
  <div class="tagcloud">
    <?php $args = array(
        'smallest'                  => 13,
        'largest'                   => 13,
        'unit'                      => 'px',
        'number'                    => 35,
        'format'                    => 'flat',
        'orderby'                   => 'count',
        'order'                     => 'DESC',
        'taxonomy'                  => 'history_tag'
        );
    ?>
    <?php wp_tag_cloud( $args ); ?>
</div>
</article>