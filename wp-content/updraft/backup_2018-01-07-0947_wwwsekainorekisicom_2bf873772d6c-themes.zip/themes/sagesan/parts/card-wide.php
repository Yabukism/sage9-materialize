<article <?php post_class('hoverable'); ?>>
	<div class="card-panel grey lighten-5 z-depth-1 card-wide">

		<?php if (get_post_type() === 'my_keywords') {
      echo '<span class="post-type">';
      echo '用語集</span>';

      } elseif (get_post_type() === 'post') {
      echo '<span class="post-type">';
      echo '記事</span>';

      } elseif (get_post_type() === 'chronology') {
      echo '<span class="post-type">';
      echo '年表</span>';

      } elseif (get_post_type() === 'japanese-history') {
      echo '<span class="post-type">';
      echo '日本史</span>';

      } elseif (get_post_type() === 'world-history') {
      echo '<span class="post-type">';
      echo '世界史</span>';

      } else {
      echo '<span class="post-type">';
      echo 'その他</span>';
      }
    ?>


		<div class="row valign-wrapper">
			<div class="col s4 m2">
				<?php if ( has_post_thumbnail() ) { ?>
				<?php the_post_thumbnail('related-thumbnail', array( 'class' => 'circle responsive-img' )); ?>
				<?php
      } else {
    ?>
					<img src="<?php echo get_template_directory_uri(); ?>/dist/images/no-image150x150.jpg" alt="NO IMAGE" title="NO IMAGE" class="circle responsive-img">
					<?php
      }
    ?>
			</div>
			<div class="col s8 m10">
				<h2>
					<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
						<?php the_title(); ?>
					</a>
					<small><?php edit_post_link(); ?></small>
				</h2>
				<?php if ( in_array( get_post_type(), array( 'japanese-history', 'world-history' ) ) ) {
        	get_template_part('parts/history-archive-meta');
      	} else {
      		get_template_part('parts/archive-meta');
  			}
        ?>				
			</div>
		</div>
	</div>
</article>
