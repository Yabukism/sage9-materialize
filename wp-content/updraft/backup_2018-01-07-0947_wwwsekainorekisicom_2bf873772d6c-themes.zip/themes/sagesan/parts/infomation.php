<div class="col s12">
    <?php
    $args = array(
        'post_type' => 'infomation',
        'posts_per_page' => 5,
        );
    $query = new WP_Query($args);
    ?>
    <?php
    if ( $query->have_posts() ) : ?>
    <div class="ticker">
       <ul class="news-ticker">
        <?php while ( $query->have_posts() ) : $query->the_post();?>
				 <li class="news-ticker--item"><span class="margin-right05 inline-block line-height1"><?= get_the_date(); ?></span><?php the_title(); ?><span class="margin-right05 inline-block line-height1"><?php the_content(); ?></span></li>
      <?php endwhile; ?>
  </ul>
</div>
<?php endif; wp_reset_postdata(); ?>
</div>
