<section class="widget_update widget widget_top-posts">
  <h3 class="widget-title"><?php _e('UPDATE KEYWORDS','sage'); ?></h3>
  <?php // 更新記事
  $lat_args = array (
    'posts_per_page' => 6,
    'orderby' => 'modified',
    'post_type' => array('my_keywords', 'post', 'world-history', 'japanese-history'),
    );
  $lat_query = new WP_Query( $lat_args );
  ?>
  <div class="widgets-grid-layout no-grav">
    <?php while ( $lat_query->have_posts() ) : $lat_query->the_post(); ?>

      <div class="widget-grid-view-image">
      <p class="widget-grid-view-image-title"><?php the_title();?></p>
       <?php if ( has_post_thumbnail() ): ?>
        <a href="<?php the_permalink(); ?>"  title="<?php the_title_attribute(); ?>" class="bump-view" data-bump-view="tp">
          <?php the_post_thumbnail( array( 200, 200 ) ); ?>
        </a>
      <?php else: ?>
        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" class="bump-view" data-bump-view="tp">
          <img src="<?php echo get_template_directory_uri(); ?>/dist/images/no-image200x200.jpg" alt="<?php the_title_attribute(); ?>">
        </a>
      <?php endif; ?>

    </div>

  <?php endwhile; ?>
</div>
<?php wp_reset_postdata(); ?>
</section>