<article <?php post_class('macy-card hoverable'); ?>>
	<div class="macy-card-image waves-effect waves-block waves-light">
		<?php if ( has_post_thumbnail() ) { ?>
		<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
			<?php the_post_thumbnail('medium'); ?>
		</a>
		<?php
      } else {
    ?>
			<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><img src="<?php echo get_template_directory_uri(); ?>/dist/images/no-image-small-c.jpg" alt="NO IMAGE" title="NO IMAGE" class=""></a>
			<?php
      }
    ?>
				<?php if (get_post_type() === 'my_keywords') {
      echo '<span class="post-type">';
      echo '用語集</span>';

      } elseif (get_post_type() === 'post') {
      echo '<span class="post-type">';
      echo '記事</span>';

      } elseif (get_post_type() === 'chronology') {
      echo '<span class="post-type">';
      echo '年表</span>';

      } elseif (get_post_type() === 'japanese-history') {
      echo '<span class="post-type">';
      echo '日本史</span>';

      } elseif (get_post_type() === 'world-history') {
      echo '<span class="post-type">';
      echo '世界史</span>';

      } else {
      echo '<span class="post-type">';
      echo 'その他</span>';
      }
    ?>

				<div class="hide">
					<time class="entry-date updated" datetime="<?= get_post_time('c', true); ?>" itemprop="dateModified"><i class="tiny material-icons">update</i> <?= the_modified_date(); ?>
</time> , by <span class="vcard author"><span class="fn"><?php the_author(); ?></span></span>
				</div>

	</div>
	<div class="macy-card-content">

		<?php if(has_term('','chapter')){ 
				echo '<i class="material-icons tiny">turned_in_not</i>';
				the_terms( $post->ID, 'chapter', '', ' &gt; ' );
		 } elseif (has_term('','keywords_family')) {
		      echo '<i class="tiny material-icons">folder_open</i>';
      		the_terms( $post->ID, 'keywords_family', '', '/' );
			} elseif (get_post_type() === 'chronology') {
								echo '<i class="tiny material-icons">folder_open</i>年表';
			} else {
					echo '<i class="tiny material-icons">folder_open</i> <span itemprop="genre">';
					the_category(' &gt; ');
      		echo '</span>';	
		} ?>

		<?php if(post_custom('wpcf-start-year')): ?>
		<span>
<i class="tiny material-icons">history</i> <?php echo post_custom('wpcf-start-era'); ?><?php echo post_custom('wpcf-start-year'); ?>
</span>
		<?php endif; ?>

		<?php get_template_part('templates/entry','meta-flag'); ?>

		<div class="hide">
			<time class="entry-date updated" datetime="<?= get_post_time('c', true); ?>" itemprop="dateModified"><i class="tiny material-icons">update</i> <span class="margin-right05">最終更新日</span><?= the_modified_date(); ?>
</time>
		</div>
	</div>
	<div class="macy-card-action">
		<h2 class="card-title entry-title">
			<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
				<?php the_title(); ?>
			</a> <small><?php edit_post_link(); ?></small></h2>
	</div>
	<div class="hide">
		<?php get_template_part('parts/author'); ?>
	</div>
</article>
