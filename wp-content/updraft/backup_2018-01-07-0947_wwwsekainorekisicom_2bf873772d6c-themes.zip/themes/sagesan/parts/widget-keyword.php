<section class="widget widget_new-keywords z-depth-1">
  <h3 class="widget-title"><?php _e('NEW KEYWORDS','sage'); ?></h3>
  <?php // 更新記事
  $lat_args = array (
    'posts_per_page' => 5,
    'post_type' => 'my_keywords',
    );
  $lat_query = new WP_Query( $lat_args );
  ?>
  <ul class="new-keywords">
    <?php while ( $lat_query->have_posts() ) : $lat_query->the_post(); ?>
      <li class="clearfix">
        <div class="thumb">
          <?php if ( has_post_thumbnail() ): ?>
            <a href="<?php the_permalink(); ?>"  title="<?php the_title_attribute(); ?>">
              <?php the_post_thumbnail( 'tooltip-thumbnail' , array('class' => 'saturate-img')); ?>
            </a>
          <?php else: ?>
            <a href="<?php the_permalink(); ?>"  title="<?php the_title_attribute(); ?>">
              <img src="<?php echo get_template_directory_uri(); ?>/dist/images/no-image150x150.jpg" alt="NO IMAGE" title="NO IMAGE" class="saturate-img">
            </a>
          <?php endif; ?>
        </div>
        <div class="infomations">
          <h5>
            <a href="<?php the_permalink(); ?>" class="new-entry-title"><?php the_title();?></a>
          </h5>
        </div>
      </li>
    <?php endwhile; ?>
  </ul>
  <?php wp_reset_postdata(); ?>
</section>