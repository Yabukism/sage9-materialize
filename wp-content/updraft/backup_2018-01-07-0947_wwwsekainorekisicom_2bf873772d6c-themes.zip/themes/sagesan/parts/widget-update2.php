<section class="widget_recent_entries widget">
  <h3 class="widget-title"><?php _e('UPDATE','sage'); ?></h3>
  <?php // 更新記事 footer用
  $lat_args = array (
    'posts_per_page' => 10,
    'orderby' => 'modified',
    'post_type' => array('my_keywords', 'post', 'japanese-history', 'world-history'),
    );
  $lat_query = new WP_Query( $lat_args );
  ?>
  <ul>
    <?php while ( $lat_query->have_posts() ) : $lat_query->the_post(); ?>
      <li><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title();?></a></li>
  <?php endwhile; ?>
</ul>
<?php wp_reset_postdata(); ?>
</section>