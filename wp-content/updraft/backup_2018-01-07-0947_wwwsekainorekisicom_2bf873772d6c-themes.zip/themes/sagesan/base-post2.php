<?php
use Roots\Sage\Setup;
use Roots\Sage\Wrapper;
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<?php get_template_part('templates/head'); ?>
<body <?php body_class('base-post2'); ?>>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MX2JBZ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <!--[if IE]>
      <div class="alert alert-warning">
        <?php _e('You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.', 'sage'); ?>
      </div>
      <![endif]-->
      <?php
      do_action('get_header');
      get_template_part('parts/sidenav');
      ?>
      <main id="Main" class="wrap">
        <div id="wrap" class="container" role="document">
          <?php if ( function_exists('yoast_breadcrumb') )
          {yoast_breadcrumb('<div class="breadcrumbs text-small">','</div>');} ?>
          <div class="content row">
            <?php
            if(is_archive() || is_search() || is_page(array('search', 'keywords-lists', 'contact', 'downloads')) || is_singular('wpdmpro') ){
              echo '<section id="main-col" class="main col s12 m9 keycover">';
            } elseif (is_page('map-search') ) {
              echo '<section id="main-col" class="main col s12 keycover">';

            } else {
              echo '<section id="main-col" class="main col s12 m8 keycover">';
            }
            ?>
            <?php //include Wrapper\template_path(); ?>
            <?php get_template_part( 'templates/content', 'single-post2' ); ?>
          </section><!-- /.main -->
          <?php if (Setup\display_sidebar()) : ?>
            <?php
            if(is_archive() || is_search() || is_page(array('search', 'keywords-lists', 'contact'))){
              echo '<aside id="sidebar" class="sidebar col s12 m3">';

            } else {
              echo '<aside id="sidebar" class="sidebar col s12 m4">';
            }
            ?>
            <?php //include Wrapper\sidebar_path(); ?>
<?php if (is_page('timeline')){
		get_template_part('templates/sidebar' , 'timeline');
		} elseif (get_post_type() === 'world-history' || 	get_post_type() === 'japanese-history'){
		get_template_part('templates/sidebar', 'history');
		}elseif (is_single()){
				get_template_part('templates/sidebar', 'single');
		} else {
				get_template_part('templates/sidebar', 'primary');
		}
?>
          </aside><!-- /.sidebar -->
        <?php endif; ?>
      </div><!-- /.content -->
    </div>
  </main><!-- /.wrap -->
  <?php
  do_action('get_footer');
  get_template_part('templates/footer');
  get_template_part('parts/footer','custom-field');
  wp_footer();
  ?>
  <?php get_template_part('parts/footer', 'outside'); ?>
</body>
</html>
