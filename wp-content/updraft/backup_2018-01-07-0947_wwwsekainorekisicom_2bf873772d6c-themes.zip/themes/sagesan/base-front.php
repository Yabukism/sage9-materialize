<?php
use Roots\Sage\Setup;
use Roots\Sage\Wrapper;
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<?php get_template_part('templates/head'); ?>
<body <?php body_class('base-front'); ?>>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MX2JBZ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <!--[if IE]>
      <div class="alert alert-warning">
        <?php _e('You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.', 'sage'); ?>
      </div>
      <![endif]-->
      <?php
      do_action('get_header');
      get_template_part('parts/sidenav');
      ?>
      <main id="Main" class="wrap">
        <?php get_template_part( 'parts/featured-home' ); ?>
        <div class="container">
          <div class="content">
          <?php get_template_part('parts/infomation'); ?>
            <section class="main">
              <?php include Wrapper\template_path(); ?>
            </section><!-- /.main -->
          </div><!-- /.content -->
        </div>
      </main><!-- /.wrap -->
      <?php
      do_action('get_footer');
      get_template_part('templates/footer');
      wp_footer();
      ?>
      <?php get_template_part('parts/footer', 'outside'); ?>
      <?php get_template_part('vendor/jquery.simpleTicker'); ?>
      <?php get_template_part('vendor/macygrid'); ?>

    </body>
    </html>