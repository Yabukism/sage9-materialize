<?php

namespace Roots\Sage\Setup;

use Roots\Sage\Assets;

/**
 * Theme setup
 */
function setup() {
  // Enable features from Soil when plugin is activated
  // https://roots.io/plugins/soil/
  add_theme_support('soil-clean-up');
  //add_theme_support('soil-nav-walker');
  add_theme_support('soil-disable-asset-versioning');
  add_theme_support('soil-disable-trackbacks');
  add_theme_support('soil-nice-search');
		//add_theme_support('soil-jquery-cdn');
  load_theme_textdomain('sage', get_template_directory() . '/lang');

  // Enable plugins to manage the document title
  // http://codex.wordpress.org/Function_Reference/add_theme_support#Title_Tag
  add_theme_support('title-tag');

  // Register wp_nav_menu() menus
  // http://codex.wordpress.org/Function_Reference/register_nav_menus
	
	// Register wp-materialize-navwalker
// require_once get_template_directory() . '/lib/wp_materialize_navwalker.php';
	
  register_nav_menus([
    'primary_navigation' => __('Primary Navigation', 'sage'),
    'mobile_navigation' => __('Mobile Navigation', 'sage'),
    'footer_navigation' => __('Footer Navigation', 'sage'),
    'top_navigation1' => __('Topbar Navigation1', 'sage'),
    'top_navigation2' => __('Topbar Navigation2', 'sage'),
    'top_navigation3' => __('Topbar Navigation3', 'sage'),
    'top_navigation4' => __('Topbar Navigation4', 'sage'),
    'top_navigation5' => __('Topbar Navigation5', 'sage'),
    'top_navigation6' => __('Topbar Navigation6', 'sage')
    ]);

  // Enable post thumbnails
  // http://codex.wordpress.org/Post_Thumbnails
  // http://codex.wordpress.org/Function_Reference/set_post_thumbnail_size
  // http://codex.wordpress.org/Function_Reference/add_image_size
  add_theme_support('post-thumbnails');
  add_image_size( 'related-thumbnail', 182, 182, true ); // related widget 4カラム
  add_image_size( 'archive-thumbnail', 286, 286, true ); // sidebar+3カラムサムネイル archive
  add_image_size( 'card-search-thumbnail', 294, 294, true ); // home+4カラムサムネイル archive
  add_image_size( 'single-main-thumbnail', 824, 341, true ); // single page top image
  add_image_size( 'tooltip-thumbnail', 150, 150, true );

  // Enable post formats
  // http://codex.wordpress.org/Post_Formats
  add_theme_support('post-formats', ['aside', 'gallery', 'link', 'image', 'quote', 'video', 'audio']);

  // Enable HTML5 markup support
  // http://codex.wordpress.org/Function_Reference/add_theme_support#HTML5
  add_theme_support('html5', ['caption', 'comment-form', 'comment-list', 'gallery', 'search-form']);

  // Use main stylesheet for visual editor
  // To add custom styles edit /assets/styles/layouts/_tinymce.scss
  add_editor_style(Assets\asset_path('styles/main.css'));
}
add_action('after_setup_theme', __NAMESPACE__ . '\\setup');

/**
 * Register sidebars
 */
function widgets_init() {
  register_sidebar([
    'name'          => __('Primary', 'sage'),
    'id'            => 'sidebar-primary',
    'before_widget' => '<section id="%1$s" class="widget %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('Single', 'sage'),
    'id'            => 'sidebar-single',
    'before_widget' => '<section id="%1$s" class="widget %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('Toc', 'sage'),
    'id'            => 'toc-widgets',
    'before_widget' => '<section id="%1$s" class="widget %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('Timeline', 'sage'),
    'id'            => 'sidebar-timeline',
    'before_widget' => '<section id="%1$s" class="widget z-depth-1 %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('Footer1', 'sage'),
    'id'            => 'sidebar-footer1',
    'before_widget' => '<section id="%1$s" class="widget %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('Footer2', 'sage'),
    'id'            => 'sidebar-footer2',
    'before_widget' => '<section id="%1$s" class="widget %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('Footer3', 'sage'),
    'id'            => 'sidebar-footer3',
    'before_widget' => '<section id="%1$s" class="widget %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('Footer4', 'sage'),
    'id'            => 'sidebar-footer4',
    'before_widget' => '<section id="%1$s" class="widget %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('related-widgets', 'sage'),
    'id'            => 'related-widgets',
    'before_widget' => '<section id="%1$s" class="widget %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
  register_sidebar([
    'name'          => __('history-widgets', 'sage'),
    'id'            => 'history-widgets',
    'before_widget' => '<section id="%1$s" class="widget %1$s %2$s">',
    'after_widget'  => '</section>',
    'before_title'  => '<h3 class="widget-title">',
    'after_title'   => '</h3>'
    ]);
}
add_action('widgets_init', __NAMESPACE__ . '\\widgets_init');

/**
 * Determine which pages should NOT display the sidebar
 */
function display_sidebar() {
  static $display;

  isset($display) || $display = !in_array(true, [
    // The sidebar will NOT be displayed if ANY of the following return true.
    // @link https://codex.wordpress.org/Conditional_Tags
    is_404(),
    is_front_page(),
    is_page_template('template-custom.php'),
    ]);

  return apply_filters('sage/display_sidebar', $display);
}

/**
 * Theme assets
 */
function assets() {
  wp_enqueue_style( 'sage/css', Assets\asset_path('styles/main.css'), false, null);
  wp_dequeue_style( 'search-filter-plugin-styles' );
  wp_dequeue_style( 'search-filter-chosen-styles' );
  wp_dequeue_style( 'dlm-frontend' );
  wp_dequeue_style( 'dlm-page-addon-frontend' );
  wp_dequeue_style( 'mci-footnotes-css-public' );
  wp_dequeue_style( 'amazonjs' );


		if (!is_admin()) {
			wp_deregister_script('jquery');

			wp_register_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js', array(), '2.2.4');
	}

  if (is_single() && comments_open() && get_option('thread_comments')) {
   wp_enqueue_script('comment-reply');
  }
		
  wp_enqueue_script('sage/js', Assets\asset_path('scripts/main.js'), ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', __NAMESPACE__ . '\\assets', 100);
