<?php
// Pagination for paged posts, Page 1, Page 2, Page 3, with Next and Previous Links, No plugin https://github.com/knone1/materializecss-wordpress/blob/master/functions.php
function materialize_pagination()
{
    global $wp_query;
    $big = 999999999;
    echo '<div class="row"><div class="pagination center-align col s12">';
    echo paginate_links(array(
        'base' => str_replace($big, '%#%', get_pagenum_link($big)),
        'format' => '?paged=%#%',
        'current' => max(1, get_query_var('paged')),
        'total' => $wp_query->max_num_pages,
        'prev_text' => '<i class="material-icons">chevron_left</i>',
        'next_text' => '<i class="material-icons">chevron_right</i>'
    ));
    echo '</div></div>';
}
