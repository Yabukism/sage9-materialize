<?php get_template_part('templates/page', 'header'); ?>

<p>
	<?php _e('Sorry, but the page you were trying to view does not exist.', 'sage'); ?>
</p>


<ul id="home-search" class="collapsible" data-collapsible="accordion">
	<li>
	<div class="collapsible-header active">
			<i class="material-icons">search</i>
			<small>検索は選択後"検索ボタン"をクリックしてください。デフォルトは記事のアップデート日順に並んでいます。</small>
			<span class="icon"></span>
		</div>
		<div class="collapsible-body">
			<div class="header-search-block">
				<?php echo do_shortcode( '[searchandfilter id="5797"]'); ?>
			</div>
		</div>
	</li>
</ul>
<?php echo do_shortcode('[searchandfilter id="5797" show="results"]'); ?>
