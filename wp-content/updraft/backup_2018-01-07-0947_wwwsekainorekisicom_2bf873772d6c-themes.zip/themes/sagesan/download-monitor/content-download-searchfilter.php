<article class="col s12 m6 l4 searchi-filter-download">
  <div class="row">
    <div class="download-title col s12">
      <h2 class="widget-title"><?php $dlm_download->the_title(); ?></h2>
    </div>
    <div class="download-image col s12">
      <?php $dlm_download->the_image(); ?>
    </div>
    <div class="download-description col m12">
    <p class="small">地図詳細</p>
    <h3><?php $dlm_download->the_short_description(); ?></h3>
      
    </div>
    <div class="download-file col s12">
      <ul class="download-info grey-text text-darken-1 small">
        <li>ファイル名: <?php $dlm_download->the_filename(); ?></li>
        <li>サイズ: <?php $dlm_download->the_filesize(); ?></li>
        <li>(<?php printf( _n( '1 download', '%d downloads', $dlm_download->get_the_download_count(), 'download-monitor' ), $dlm_download->get_the_download_count() ) ?>)</li>
      </ul>
    </div> 
    <div class="download-btn center-align">
      <a class="waves-effect waves-light btn" title="<?php if ( $dlm_download->has_version_number() ) {
        printf( __( 'Version %s', 'download-monitor' ), $dlm_download->get_the_version_number() );
      } ?>" href="<?php $dlm_download->the_download_link(); ?>" rel="nofollow">
      <i class="material-icons left">cloud_download</i>
      <?php _e( 'Download File', 'download-monitor' ); ?>
    </a>
  </div>
</div>
</article>