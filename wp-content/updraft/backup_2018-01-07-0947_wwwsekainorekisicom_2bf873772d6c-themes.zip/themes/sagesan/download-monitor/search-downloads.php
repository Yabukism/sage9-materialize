<?php global $post; ?>
<div class="download-search col s12 l6">
  <form method="GET" id="download-search" action="<?php echo get_permalink( $post->ID ); ?>">
    <div class="input-field">
      <input type="text" id="download_search" name="download_search" />
      <label for="download_search"><?php _e( 'Search Downloads...', 'sage' ); ?></label>

      <input type="submit" value="<?php _e( 'Search', 'sage' ); ?>" />
      <?php if ( isset( $_GET['page_id'] ) ) : ?>
       <input type="hidden" name="page_id" value="<?php echo esc_attr( absint( $_GET['page_id'] ) ); ?>" />
     <?php endif; ?>
   </div>
 </form>
</div>
<div class="download-categories col s12 l6">
  <span class="screen-reader-text">カテゴリ</span>
  <ul>
    <li><a href="/downloads/download-category/%e4%b8%96%e7%95%8c/" title="世界">世界</a></li>
    <li><a href="/downloads/download-category/%e3%83%a8%e3%83%bc%e3%83%ad%e3%83%83%e3%83%91/" title="ヨーロッパ">ヨーロッパ</a></li>
    <li><a href="/downloads/download-category/%e3%82%a2%e3%82%b8%e3%82%a2/" title="アジア">アジア</a></li>
  </ul>
</div>
