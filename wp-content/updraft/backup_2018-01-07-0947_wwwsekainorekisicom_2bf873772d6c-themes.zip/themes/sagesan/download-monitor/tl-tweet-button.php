<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly
?>
<p class="dlm-tl-tweet-button"><a class="waves-effect waves-light btn-large blue" href="<?php echo add_query_arg( 'dlm-tl-unlock', 1, $download->get_the_download_link() ); ?>" onclick="return DLM_TL_Unlock_Download('<?php echo add_query_arg( 'dlm-tl-unlock', 1, $download->get_the_download_link() ); ?>');"><?php echo apply_filters( 'dlm_tl_download_button_label', __( 'Tweet to Unlock Download Map', 'dlm-twitter-lock' ) );    ?></a></p>