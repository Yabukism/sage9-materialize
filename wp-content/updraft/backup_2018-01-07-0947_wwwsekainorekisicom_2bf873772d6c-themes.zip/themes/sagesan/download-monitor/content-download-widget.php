<?php
/**
 * Shows title only.
 */
if ( ! defined( 'ABSPATH' ) ) {
  exit;
} // Exit if accessed directly
global $dlm_download, $dlm_page_addon;
?>
<a class="download-link" title="<?php if ( $dlm_download->has_version_number() ) {
  printf( __( 'Version %s', 'download-monitor' ), $dlm_download->get_the_version_number() );
} ?>" href="<?php echo $dlm_page_addon->get_download_info_link( $dlm_download ); ?>" rel="nofollow">
  <i class="material-icons tiny">cloud_download</i> <?php $dlm_download->the_title(); ?>
</a>