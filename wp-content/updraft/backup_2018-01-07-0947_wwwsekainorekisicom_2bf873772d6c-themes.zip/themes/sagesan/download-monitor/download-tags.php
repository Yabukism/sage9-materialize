<div id="download-page-tags" class="download_group col s12">
	<span class="screen-reader-text">タグ</span>
	<?php echo wp_generate_tag_cloud( $tags, array( 'orderby' => 'count', 'order' => 'DESC', 'number' => '100' )); ?>
	</div>
