<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<title><?php _e( 'Download Successfully Unlocked', 'dlm-twitter-lock' ); ?></title>
	<?php wp_head(); ?>
	<style type="text/css">
		.dlm-twitter-lock-success-message {
			padding: 5% 10%;
			text-align: center;
		}
	</style>
</head>
<body>
<div class="dlm-twitter-lock-success-message">
	<h1><?php _e( 'Download unlocked!', 'dlm-twitter-lock' ); ?></h1>
	<p><?php _e( "You've successfully unlocked the download.", 'dlm-twitter-lock' ); ?></p>
	<?php echo do_shortcode( '[download id="' . $download->id . '" template="button"]' ); ?>
</div>
</body>
</html>