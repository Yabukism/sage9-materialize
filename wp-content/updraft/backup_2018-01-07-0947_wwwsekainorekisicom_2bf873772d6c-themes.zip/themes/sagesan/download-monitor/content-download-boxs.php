<aside class="col s12 m6">
  <div class="card medium">
    <div class="card-image">
      <?php $dlm_download->the_image(); ?>
    </div>
    <div class="card-content">
    <h2 class="widget-title black-text"><?php $dlm_download->the_title(); ?></h2>
      <?php $dlm_download->the_short_description(); ?>
      <p class="right-align grey-text text-darken-1"><small><?php $dlm_download->the_filename(); ?> &ndash; <?php $dlm_download->the_filesize(); ?>, <?php printf( _n( '1 download', '%d downloads', $dlm_download->get_the_download_count(), 'download-monitor' ), $dlm_download->get_the_download_count() ) ?></small></p>
      <div class="card-action center-align">
        <a class="waves-effect waves-light btn-large" title="<?php if ( $dlm_download->has_version_number() ) {
          printf( __( 'Version %s', 'download-monitor' ), $dlm_download->get_the_version_number() );
        } ?>" href="<?php $dlm_download->the_download_link(); ?>" rel="nofollow">
        <i class="material-icons left">cloud_download</i>
        <?php _e( 'Download File', 'download-monitor' ); ?>
      </a>
    </div>
  </div>
</aside>