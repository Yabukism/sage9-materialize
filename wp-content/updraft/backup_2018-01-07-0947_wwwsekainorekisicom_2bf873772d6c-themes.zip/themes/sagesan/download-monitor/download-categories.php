<?php global $dlm_page_addon; ?>
<div class="row">
  <div class="download_category col s12">
   <div class="col s9">
     <h3 id="i-<?php echo $category->name; ?>"><a href="<?php echo $dlm_page_addon->get_category_link( $category ); ?>"><?php echo $category->name; ?> <?php if ( $category->count ) : ?><span class="badge new blue-grey lighten-3" data-badge-caption="コンテンツ"><?php echo $category->count; ?></span><?php endif; ?></a></h3>
   </div>
   <div class="col s3">
    <p class="right-align"><a href="<?php echo $dlm_page_addon->get_category_link( $category ); ?>">MORE<i class="material-icons">keyboard_arrow_right</i></a></p>
  </div>
  <?php while ( $downloads->have_posts() ) : $downloads->the_post(); ?>
   <?php $dlm_download = new DLM_Download( get_the_ID() ); ?>

   <?php $template_handler = new DLM_Template_Handler(); $template_handler->get_template_part( 'content-download', $format, $dlm_page_addon->plugin_path() . 'templates/', array( 'dlm_download' => $dlm_download ) ); ?>

 <?php endwhile; ?>
</div>
</div>