<?php
/**
 * Default output for a download via the [download] shortcode
 */
global $dlm_download, $dlm_page_addon;
?>

  <div class="download-archive col s12 m12 l6">
    <div class="card-image col s4 m3 l4">
      <a class="download-link" href="<?php echo $dlm_page_addon->get_download_info_link( $dlm_download ); ?>" rel="nofollow">
        <?php echo $dlm_download->get_the_image( 'archive-thumbnail' ); ?>
      </a>
    </div>

    <div class="card-action col s8 m9 l8">
      <a class="download-link" href="<?php echo $dlm_page_addon->get_download_info_link( $dlm_download ); ?>" rel="nofollow"><span class="card-title grey-text text-darken-4"><?php $dlm_download->the_title(); ?> (<?php printf( _n( '1', '%d', $dlm_download->get_the_download_count(), 'dlm_page_addon' ), $dlm_download->get_the_download_count() ) ?>)</span>
      </a>
    </div>
  </div>
