<div class="post-meta">
  <span class="meta-category ">
    <?php
      echo '<i class="tiny material-icons">folder_open</i> <span itemprop="genre">';
      the_category(' ');
      echo '</span>';
    ?>
  </span>
  <span class="meta-date">
    <time class="entry-date publish date updated date" datetime="<?= get_post_time('c', true); ?>" itemprop="datePublished"><i class="tiny material-icons">date_range</i> <?= get_the_date(); ?>
    </time>
    <time class="entry-date updated" datetime="<?= get_post_time('c', true); ?>" itemprop="dateModified"><i class="tiny material-icons">update</i> <?= the_modified_date(); ?>
    </time>
  </span>
  <span class="meta-category ">
    <i class="material-icons tiny">loyalty</i>
    <?php if(has_term('','history_tag')){ ?>
     <?php the_terms( $post->ID, 'history_tag', '', ' ', "" ); ?>
     <?php } ?>
   </span>

 </div>