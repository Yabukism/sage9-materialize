<footer id="Main-footer" class="page-footer">
  <div class="footer-copyright text-small ">
    <div class="container">
      <div class="row margin-bottom0">
        <div class="col s12 m6 copyright">
          &copy; <?php echo date("Y"); ?> <?php bloginfo( 'name' ); ?>
        </div>
        <div class="col s12 m6 right-align">
          <?php wp_nav_menu(array(
            'container' => '',
            'theme_location'  => 'footer_navigation',
            'menu_class' => 'menus',
            )); ?>
          </div>
        </div>
      </div>
    </div>
  </footer>