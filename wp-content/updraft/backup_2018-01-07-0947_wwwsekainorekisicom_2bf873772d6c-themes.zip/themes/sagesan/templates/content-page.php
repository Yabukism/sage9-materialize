<div class="entry-page-content">
	<?php the_content(); ?>
	
</div>

<?php do_action( 'materialize_after_content' ); ?>
<footer>
	<?php
	get_template_part('parts/sharing');
	get_template_part('parts/amazon');
	?>
</footer>
