<?php while (have_posts()) : the_post(); ?>
  <article <?php post_class('content-timeline'); ?>>

  <div class="entry-content">
    
    <?php the_content(); ?>
    
    <?php get_template_part('parts/author'); ?>
    <?php get_template_part('parts/sharing'); ?>
    <?php get_template_part('parts/amazon'); ?>
  </div>
  <?php do_action( 'materialize_after_content' ); ?>

</article>
<?php endwhile; ?>
