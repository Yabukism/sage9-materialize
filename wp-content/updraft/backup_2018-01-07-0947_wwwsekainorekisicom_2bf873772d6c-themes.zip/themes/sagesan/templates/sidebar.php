<div class="margin-bottom1">
	<?php get_template_part('parts/adsense-download'); ?>
</div>
<?php get_template_part('parts/widget','update'); ?>
<?php dynamic_sidebar('sidebar-primary'); ?>
