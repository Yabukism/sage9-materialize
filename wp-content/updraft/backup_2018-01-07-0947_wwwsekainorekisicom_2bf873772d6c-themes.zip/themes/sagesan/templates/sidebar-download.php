<div class="hide-on-small-only">
    <?php dynamic_sidebar('download-widgets'); ?>
</div>