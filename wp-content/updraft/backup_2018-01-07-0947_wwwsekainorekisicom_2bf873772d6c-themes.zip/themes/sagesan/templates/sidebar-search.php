<div class="hide-on-small-only">
    <?php dynamic_sidebar('sidebar-search'); ?>
</div>