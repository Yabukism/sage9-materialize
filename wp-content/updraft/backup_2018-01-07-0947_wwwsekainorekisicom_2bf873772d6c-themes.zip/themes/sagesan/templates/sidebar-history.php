<div class="margin-bottom1">
	<?php get_template_part('parts/adsense-download'); ?>
</div>

<?php dynamic_sidebar( 'history-widgets' ); ?>

<?php get_template_part('parts/this-info-contents'); ?>

<?php get_template_part('parts/widget','pagetop'); ?>