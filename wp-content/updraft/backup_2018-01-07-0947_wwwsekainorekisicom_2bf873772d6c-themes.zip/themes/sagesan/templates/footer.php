<footer id="Main-footer" class="page-footer">
  <div class="container">
    <div class="row">
      <div class="col s12 m6 l3">
       	<?php get_template_part('parts/widget','keyword-category'); ?>
        <?php dynamic_sidebar('sidebar-footer1'); ?>       
      </div>
      <div class="col s12 m6 l3">
          <?php get_template_part('parts/widget','history-category'); ?>
          <?php dynamic_sidebar('sidebar-footer2'); ?>
          
        </div>
        <div class="col s12 m6 l3">
          <?php get_template_part('parts/widget','history-category2'); ?>
          <?php dynamic_sidebar('sidebar-footer3'); ?>
        </div>
        <div class="col s12 m6 l3">
          <?php dynamic_sidebar('sidebar-footer4'); ?>
          <?php get_template_part('parts/widget', 'update2'); ?>
        </div>
      </div>
    </div>
    <div class="footer-copyright text-small ">
      <div class="container">
        <div class="row margin-bottom0">
          <div class="col s12 m6 copyright">
            &copy; <?php echo date("Y"); ?> <?php bloginfo( 'name' ); ?>
          </div>
          <div class="col s12 m6 right-align">
           <?php wp_nav_menu(array(
            'container' => '',
            'theme_location'  => 'footer_navigation',
            'menu_class' => 'menus',
            )); ?>
            <ul class="menus">
              <li><a href="https://www.facebook.com/sekainorekishi/"><i class="icomoon icon-facebook"></i></a></li>
              <li><span class="twitter"><a href="https://twitter.com/joe___yabuki"><i class="icomoon icon-twitter"></i></a></span></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </footer>