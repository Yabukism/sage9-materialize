<header id="masthead" class="site-header" role="banner">
  <nav id="site-navigation" role="navigation">
    <div class="container">
      <div class="nav-wrapper">
        <?php wp_nav_menu (
          array(
            'theme_location'  => 'primary_navigation',
            'container'       => false,
            'menu_id'         => 'top-navigation',
            'menu_class'      => 'right hide-on-med-and-down',
            'echo'            => true,
            'fallback_cb'     => 'wp_page_menu',
            'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
            'depth'           => 2,
            )
          );
          ?>
          </div>
        </div>
      </nav><!-- #site-navigation -->
    </header><!-- #masthead -->

