<div class="meta-flag">
  <?php $terms = wp_get_object_terms($post->ID,'country'); 
  foreach($terms as $term){ 
    echo '<i class="sprite sprite-';
    echo $term->slug.''; 
    echo '"></i>';
    echo '<a href="' . get_term_link( $term->slug, 'country' ) . '">' . esc_html( $term->name ) . '</a> ';
  }
  ?>
</div>
