<div class="margin-bottom1">
	<?php get_template_part('parts/adsense-download'); ?>
</div>

<?php if ( has_term( 'world-heritage','keywords_family' ) ) {
  get_template_part('parts/world-heritage');
}
?>

<?php if ( is_object_in_term($post->ID, 'keywords_family','person') ){
  get_template_part('parts/profile');
}
?>

<?php if ( in_category( array( 'movie', 'dorama' ))){
  get_template_part('parts/movie');
}
?>

<?php get_template_part('parts/widget','update'); ?>
 
<?php dynamic_sidebar( 'sidebar-single' ); ?>

<?php get_template_part('parts/this-info-contents'); ?>

<?php get_template_part('parts/widget','pagetop'); ?>
