<?php use Roots\Sage\Titles; ?>

<header class="page-header">
  <h1 class="entry-title"><?= Titles\title(); ?></h1>
<?php
if (is_archive()) {
?>
<span class="small"> <?php echo category_description(get_the_category()); ?> </span>
<?php
  }
?>
</header>
