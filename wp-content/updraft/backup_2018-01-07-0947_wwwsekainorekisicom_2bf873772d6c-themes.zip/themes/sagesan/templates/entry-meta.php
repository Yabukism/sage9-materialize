<span class="meta-category block">
    <?php if(has_term('','keywords_family')){
      echo '<i class="tiny material-icons">folder_open</i>';
      the_terms( $post->ID, 'keywords_family', '', '/' );
    } else {
      echo '<i class="tiny material-icons">folder_open</i> <span itemprop="genre">';
      the_category(' &gt; ', 'single' );
      echo '</span>'; } ?>
</span>

<time class="entry-date publish date updated date" datetime="<?= get_post_time('c', true); ?>" itemprop="datePublished"><i class="tiny material-icons">date_range</i> <span class="margin-right05">公開日</span><?= get_the_date(); ?>
    </time>
<time class="entry-date updated" datetime="<?= get_post_time('c', true); ?>" itemprop="dateModified"><i class="tiny material-icons">update</i> <span class="margin-right05">最終更新日</span><?= the_modified_date(); ?>
    </time>

<?php if(has_term('','history_tag')){ ?>
<span class="block">
    <i class="material-icons tiny">loyalty</i>
     <?php the_terms( $post->ID, 'history_tag', '', ' / ', "" ); ?>
</span>
<?php } ?>
<?php get_template_part('templates/entry','meta-flag'); ?>
