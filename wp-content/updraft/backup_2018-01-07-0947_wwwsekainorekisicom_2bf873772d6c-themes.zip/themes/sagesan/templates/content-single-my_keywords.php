<?php while (have_posts()) : the_post(); ?>
  <article <?php post_class('content-single-my_keywords'); ?>>
   <header class="primary-color-light col s12 margin-bottom2">
     <?php
     if ( has_post_thumbnail() ) {
      $full_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
      $full_width = $full_image_url[1];
      $image_excerpt = get_post( get_post_thumbnail_id() )->post_excerpt;
      echo '<div class="col s12 m6 l6">';
      echo '<figure class="wp-caption herf-img">';
      echo '<img class="materialboxed responsive-img herf-img" width="'
      . $full_width .
      '" src="'
      . $full_image_url[0] .
      '" alt="'
      . the_title_attribute('echo=0') .
      '" data-caption="'
      . the_title_attribute( 'echo=0' ) .
      '">';
      echo '<figcaption class="wp-caption-text">' ;
      echo $image_excerpt;
      echo '</figcaption>';
      echo '</figure>';
      echo '</div>';
    }
    ?>
    <div class="col s12 m6 l6">
      <h1 class="entry-title"><?php the_title(); ?></h1>
      <?php get_template_part('templates/entry-meta'); ?>     
    </div>
  </header>
  <div class="entry-content">
    
    <?php the_content(); ?>
 
    <!-- 同時代の人物  -->
    <?php if(post_custom('wpcf-contemporaries')): ?>

					<div class="contemporaries margin-top2 margin-bottom1 padding1 teal lighten-2 z-depth-2">
       <div class="contemporaries-content white-text">
								<span class="contemporaries-title">同時代の人物</span>
        <p><i class="tiny material-icons">face</i> <?php echo post_custom('wpcf-contemporaries'); ?><br /><?php echo post_custom('wpcf-contemporaries-info'); ?></p>
        </div>
      </div>

    <?php endif; ?>
       
    <?php get_template_part('parts/pager'); ?>
    <?php get_template_part('parts/author'); ?>
    <?php get_template_part('parts/sharing'); ?>
    <?php get_template_part('parts/amazon'); ?>
  </div>
  <?php do_action( 'materialize_after_content' ); ?>
  <footer class="margin-bottom3">
    <?php dynamic_sidebar( 'related-widgets' ); ?>
    <?php get_template_part('parts/related-adsense'); ?>
  </footer>
  <?php comments_template('/templates/comments.php'); ?>
  <?php get_template_part('parts/single-bottom-nav'); ?>

</article>
<?php endwhile; ?>
