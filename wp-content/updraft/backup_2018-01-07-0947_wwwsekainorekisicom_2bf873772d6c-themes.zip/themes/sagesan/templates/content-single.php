<?php get_template_part('parts/chapter-nav'); ?>
<?php while (have_posts()) : the_post(); ?>
<article id="column-content" <?php post_class( 'content-singlephp '); ?>>
	<header>
		<h1 class="entry-title margin-bottom1">
			<?php the_title(); ?>
		</h1>
		<?php
    if ( has_post_thumbnail() ) {
      $image_excerpt = get_post( get_post_thumbnail_id() )->post_excerpt;
      echo '<figure class="wp-caption">';
      the_post_thumbnail('single-main-thumbnail');
      echo '<figcaption class="wp-caption-text">';
      echo $image_excerpt;
      echo '</figcaption>';
      echo '</figure>';
    }
    ?>
			<div class="primary-color-light">
				<?php if ( in_array( get_post_type(), array( 'japanese-history', 'world-history' ) ) ) {
        get_template_part('parts/history-single-meta');
  
      } else {
      get_template_part('templates/entry-meta');
  }
        ?>
			</div>
	</header>
	<div class="entry-content">
		
		<?php the_content(); ?>
		<?php get_template_part('parts/pager'); ?>
		<?php get_template_part('parts/chapter-nav'); ?>
		<?php get_template_part('parts/author'); ?>
		<?php get_template_part('parts/sharing'); ?>
		<?php get_template_part('parts/amazon'); ?>
	</div>
	<?php do_action( 'materialize_after_content' ); ?>
	<footer class="margin-bottom3">
		<?php dynamic_sidebar( 'related-widgets' ); ?>
		<?php get_template_part('parts/related-adsense'); ?>
	</footer>
	<?php comments_template('/templates/comments.php'); ?>

	<?php get_template_part('parts/single-bottom-nav'); ?>

</article>
<?php endwhile; ?>
