<?php while (have_posts()) : the_post(); ?>
  <article <?php post_class('content-full'); ?>>
   <header class="col s12">
    <h1 class="entry-title margin-bottom1"><?php the_title(); ?></h1>
    <div class="primary-color-light">
      <?php get_template_part('templates/entry-meta'); ?>
    </div>
    <?php
    if ( has_post_thumbnail() ) {
      the_post_thumbnail('full');
    }
    ?>
  </header>
  <div class="col s12 m8">
    <div class="entry-content">
      
      <?php the_content(); ?>
      
      <?php get_template_part('parts/author'); ?>
      <?php get_template_part('parts/sharing'); ?>
      <?php get_template_part('parts/amazon'); ?>
    </div>
    <?php do_action( 'materialize_after_content' ); ?>
    <footer>
      <?php dynamic_sidebar( 'related-widgets' ); ?>
    </footer>
    <?php comments_template('/templates/comments.php'); ?>

    <?php get_template_part('parts/single-bottom-nav'); ?>
  </div>
  <aside id="sidebar" class="sidebar col s12 m4">
    <?php get_template_part('templates/sidebar' , 'single'); ?>
  </aside>
</article>
<?php endwhile; ?>


