<article <?php post_class('col s12 m6 l4'); ?>>
  <?php get_template_part('parts/card','archive'); ?>
</article>
