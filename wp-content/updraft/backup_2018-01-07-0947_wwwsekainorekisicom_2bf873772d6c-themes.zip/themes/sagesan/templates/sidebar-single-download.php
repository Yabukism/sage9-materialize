<section id="This-info-widget" class="widget widget_custom this-info z-depth-1">
  <h3 class="widget-title"><?php _e('POST INFORMATION','sage'); ?>
  </h3>
  <ul>
    <li>
      <div class="type"><i class="tiny material-icons">date_range</i><?php _e('Age','sage'); ?></div>
      <div class="value age-value">
        <?php
        $product_terms = wp_get_object_terms( $post->ID, 'age' );
        if ( ! empty( $product_terms ) ) {
          if ( ! is_wp_error( $product_terms ) ) {
            foreach( $product_terms as $term ) {
              echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'age' ) .'">' . esc_html( $term->name ) . '</a>';
            }
          }
        }
        ?>
      </div>
    </li>

    <?php if(post_custom('wpcf-start-year')): ?>
      <li>
        <div class="type"><i class="tiny material-icons">history</i><?php _e('Start','sage'); ?></div>
        <div class="value no-btn">
          <?php echo post_custom('wpcf-start-era'); ?><?php echo post_custom('wpcf-start-year'); ?>

          <?php if(post_custom('wpcf-start-month')): ?><?php _e('-','sage'); ?>
            <?php echo post_custom('wpcf-start-month'); ?>
          <?php endif; ?>

          <?php if(post_custom('wpcf-start-day')): ?><?php _e('-','sage'); ?>
            <?php echo post_custom('wpcf-start-day'); ?>
          <?php endif; ?>
        </div>
      </li>
    <?php endif; ?>

    <?php if(post_custom('wpcf-end-year')): ?>
      <li>
        <div class="type"><i class="tiny material-icons">history</i><?php _e('End','sage'); ?></div>
        <div class="value no-btn">
          <?php echo post_custom('wpcf-end-era'); ?><?php echo post_custom('wpcf-end-year'); ?>

          <?php if(post_custom('wpcf-end-month')): ?><?php _e('-','sage'); ?>
            <?php echo post_custom('wpcf-end-month'); ?>
          <?php endif; ?>

          <?php if(post_custom('wpcf-end-day')): ?><?php _e('-','sage'); ?>
            <?php echo post_custom('wpcf-end-day'); ?>
          <?php endif; ?>
        </div>
      </li>
    <?php endif; ?>
    <?php
    $product_terms = wp_get_object_terms( $post->ID,  'era-name' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">business</i>';
        echo ( __('Era', 'sage'));
        echo '</div>';
        echo '<div class="value ela-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'era-name' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
    <?php
    $product_terms = wp_get_object_terms( $post->ID,  'historypeople' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">people</i>';
        echo ( __('Ethnic', 'sage'));
        echo '</div>';
        echo '<div class="value ethnic-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'historypeople' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
    <?php
    $product_terms = wp_get_object_terms( $post->ID,  'historypresidents' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">person</i>';
        echo ( __('Emperor', 'sage'));
        echo '</div>';
        echo '<div class="value person-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'historypresidents' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
    <?php
    $product_terms = wp_get_object_terms( $post->ID,  'policy' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">business</i>';
        echo ( __('policy', 'sage'));
        echo '</div>';
        echo '<div class="value art-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'policy' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
    <?php
    $product_terms = wp_get_object_terms( $post->ID,  'historyart' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">brush</i>';
        echo ( __('art', 'sage'));
        echo '</div>';
        echo '<div class="value art-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'historyart' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
    <?php
    $product_terms = wp_get_object_terms( $post->ID,  'historybuilding' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">business</i>';
        echo ( __('Building', 'sage'));
        echo '</div>';
        echo '<div class="value building-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'historybuilding' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
    <?php
    $product_terms = wp_get_object_terms( $post->ID,  'history_war' );
    if ( ! empty( $product_terms ) ) {
      if ( ! is_wp_error( $product_terms ) ) {
        echo '<li><div class="type"><i class="tiny material-icons">close</i>';
        echo ( __('War', 'sage'));
        echo '</div>';
        echo '<div class="value war-value">';
        foreach( $product_terms as $term ) {
          echo '<a class="waves-effect waves-light btn-flat btn-mini" href="'. get_term_link( $term->slug, 'history_war' ) .'">' . esc_html( $term->name ) . '</a>';
        }
        echo '</div></li>';
      }
    }
    ?>
    <?php if(post_custom('wpcf-map_country')): ?>
      <li>
        <div class="type"><i class="tiny material-icons">place</i>場所</div>
        <div class="value no-btn">
          <?php echo post_custom('wpcf-map_country'); ?> <?php echo post_custom('wpcf-state'); ?> <?php echo post_custom('wpcf-city'); ?>
        </div>
      </li>
    <?php endif; ?>
    <?php if(post_custom('wpcf-s-map')): ?>
      <li>
        <?php
        $var = get_post_meta($post->ID, 'wpcf-s-map', true);
        $var2 = get_post_meta($post->ID, 'wpcf-s-map-w', true);
        if($var == '')
        {
        }else {
          echo do_shortcode( '[display_map height="200" zoom="9" scroll_wheel="false" address1=" '. $var .' | '. $var2 .' "]' );
        }
        ?>
      </li>
    <?php endif; ?>
  </ul>
</section>

<?php dynamic_sidebar( 'sidebar-single' ); ?>

