<?php
/**
 * Search & Filter Pro
 *
 * Sample Resdivts Template
 *
 * @package   Search_Filter
 * @author    Ross Morsali
 * @link      http://www.designsandcode.com/
 * @copyright 2014 Designs & Code
 *
 * Note: these templates are not fdivl page templates, rather
 * just an encaspdivation of the your resdivts loop which shodivd
 * be inserted in to other pages by using a shortcode - think
 * of it as a template part
 *
 * This template is an absolute base example showing you what
 * you can do, for more customisation see the WordPress docs
 * and using template tags -
 *
 * http://codex.wordpress.org/Template_Tags
 * homepage
 */

if ( $query->have_posts() )
{
  ?>
  <div class="row">
    <div class="col s4 m4 l4">
      <?php next_posts_link( '<i class="small material-icons">arrow_back</i>', $query->max_num_pages ); ?>
    </div>
    <div class="col s4 m4 l4">
      <p class="pagination-status">検索結果 <?php echo $query->found_posts; ?> 件 <span class="hide-on-med-and-up"><br></span><span class="grey-text">Page <?php echo $query->query['paged']; ?> / <?php echo $query->max_num_pages; ?></span></p>
    </div>
    <div class="col s4 m4 l4 right-align">
      <?php previous_posts_link( '<i class="small material-icons">arrow_forward</i>'); ?>
    </div>
  </div>
  <div id="macy-container">
      
    <?php
    while ($query->have_posts())
    {
      $query->the_post();
      ?>
      
      <div <?php post_class(); ?> itemscope itemtype="http://schema.org/CreativeWork" data-equalizer-watch> 
       
        <?php get_template_part('parts/card','archive'); ?>
      </div>
      <?php
    }
    ?>
  </div>
  <div class="row home-pagination margin-top2">
   
    <div class="col offset-s3 s1">
      <?php next_posts_link( '<i class="small material-icons">arrow_back</i>', $query->max_num_pages ); ?>
    </div>
    <div class="col s4">
      <p class="pagination-status">検索結果 <?php echo $query->found_posts; ?> 件 <span class="hide-on-med-and-up"><br></span><span class="grey-text">Page <?php echo $query->query['paged']; ?> / <?php echo $query->max_num_pages; ?></span></p>
    </div>
    <div class="col s1 right-align">
      <?php previous_posts_link( '<i class="small material-icons">arrow_forward</i>'); ?>
    </div>
  </div>

  <?php
} else {
  ?>
  <div>
    <p>お探しのページは見つかりませんでした。</p>
  </div>
  <?php
}
?>

